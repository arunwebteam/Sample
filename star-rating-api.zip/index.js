const express = require("express");
const authRoutes = require("./app/routes/auth.routes");
require('dotenv').config();
const app = express();
const cors = require('cors');
app.use(express.json());
//parse request of content-type application/x-www-form-urlencoded
app.use(express.urlencoded({extended:true}));
app.use(cors());
app.options('*', cors());

//import models 
const db = require("./app/models");

//database connections
//Example mongodb://localhost:27017/biovus_hr_db
db.mongoose
.connect(process.env.DB_URl, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => {
console.log("Successfully connect to MongoDB");
})
.catch(err => {
    console.log("Connection Error",err);
    process.exit();
});

db.Promise = global.Promise;

//calling Main Routes
app.use("/",authRoutes);

//set port, listen for requests
const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>{
    console.log(`Server is running on port ${PORT}.`);
});
