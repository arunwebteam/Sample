const mongoose = require("mongoose");
const ratingSchema = new mongoose.Schema({
    title:{
      type:String,
      required: true,
      min:5,
      maxlength:255
    },
    comments:{
        type:String,
        required: true,
        min:5,
        maxlength:500
    },
    userrating:{
     type:String
    },
})


module.exports =mongoose.model("starrate",ratingSchema);
