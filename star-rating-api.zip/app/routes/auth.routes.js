const router = require("express").Router();
const ratingctrl = require("../controller/rating.controller");

router.post("/insert",ratingctrl.insertstarrate);

router.get("/",ratingctrl.welcome);

module.exports = router;
