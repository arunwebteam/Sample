const StarRate = require("../models/modelrating.model");

const insertstarrate = async (req,res) => {
    try
    {

        const getrating = new StarRate(req.body);
        const saverating = await getrating.save();
        res.status(200).send(saverating)
    }
    catch(err)
    {
        res.send(err);
    }
};

const welcome = (req, res) => {
    res.json({message: "Welcome to Hello World"}); 
};


module.exports = {insertstarrate,welcome};